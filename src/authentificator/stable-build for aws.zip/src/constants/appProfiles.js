
const APP_PROFILES = {
    TEST: 'TEST',
    PROD: 'PROD',
}

module.exports = APP_PROFILES;